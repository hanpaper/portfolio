declare const SwiperContainer: HTMLElement;
declare const SwiperSlide: HTMLElement;
declare const register: (injectStyles?: boolean) => void;

export { register, SwiperContainer, SwiperSlide };
